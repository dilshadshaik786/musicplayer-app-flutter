package com.example.MusicLyrics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
